TweenMax.staggerFrom(".form-group", 1, {
  delay: 0.2,
  opacity: 0,
  y: 20,
  ease: Expo.easeInOut
}, 0.2);

TweenMax.staggerFrom(".contact-info-container > *", 1, {
  delay: 0,
  opacity: 0,
  y: 20,
  ease: Expo.easeInOut
}, 0.1);
